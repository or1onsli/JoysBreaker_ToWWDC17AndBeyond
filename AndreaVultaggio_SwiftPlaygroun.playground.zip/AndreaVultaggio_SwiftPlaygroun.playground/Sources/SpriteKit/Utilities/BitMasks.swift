//
//  BitMasks.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/* 
 * This simple struct contains all the categoryBitMasks of the elements of the game.
 */

struct BodyType {
    
    static let ball: UInt32 = 3
    static let bottom: UInt32 = 33
    static let brick: UInt32 = 5
    static let paddle: UInt32 = 7
    static let borders: UInt32 = 17
    static let power: UInt32 = 3

}

