//
//  Textures.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This struct contains three enums which contain the correct path to the texture files.
 */

struct Textures {
    
    enum brick: String {
        case green = "Textures/Bricks' Textures/greenBrick",
             yellow = "Textures/Bricks' Textures/yellowBrick",
             orange = "Textures/Bricks' Textures/orangeBrick",
             red = "Textures/Bricks' Textures/redBrick",
             purple = "Textures/Bricks' Textures/purpleBrick",
             blue = "Textures/Bricks' Textures/blueBrick"
    }
    
    enum paddle: String {
        case normal = "Textures/paddleNormal",
             background = "Textures/background"
    }
    
    enum power: String {
        case frame1 = "Textures/Power Textures/frame1",
             frame2 = "Textures/Power Textures/frame2",
             frame3 = "Textures/Power Textures/frame3",
             frame4 = "Textures/Power Textures/frame4",
             frame5 = "Textures/Power Textures/frame5",
             frame6 = "Textures/Power Textures/frame6",
             frame7 = "Textures/Power Textures/frame7"
    }
}
