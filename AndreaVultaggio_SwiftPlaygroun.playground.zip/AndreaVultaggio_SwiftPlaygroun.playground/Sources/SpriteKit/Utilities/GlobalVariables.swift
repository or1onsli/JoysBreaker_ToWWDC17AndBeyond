//
//  GlobalVariables.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This file contains all the costants, some variables useful for the Playground demostrantion
 * and a customClass for handling variables' modification.
 */

import Foundation

//Borders

let borderBarMin = 50
let borderBarMid = 1200
let borderBarMax = 2048
let borderBarRightXPos = 1998

//Paddle
let paddleX = 1024
let paddleY = 50

//Bricks
let brickWidthAndDelta = 152
let brickHeightAndDelta = 55
let brickFirstXPosition = 60
let brickFirstYPosition = 1400

//Ball Impulse
var maxSpeed: CGFloat = 400
let impulseValue = 35

//Bodyguards Velocity
var bodyguard1: CGFloat = 543.21
var bodyguard2: CGFloat = 1432.88
var bodyguard3: CGFloat = 1000.23

//Power Values
var radius: Float = 70
var strength: Float = -5

//Timer

var timeLeft = 100

public class SliderHandler: NSObject {
    
    public func setTimeLeft(_ newValue: Int) -> Void {
        timeLeft = newValue
    }
    
    public func setRadius(_ newValue: Float) -> Void {
        radius = newValue
    }
    
    public func setStrength(_ newValue: Float) -> Void {
        strength = newValue
    }
    
    public func setMaxSpeed(_ newValue: CGFloat) -> Void {
        maxSpeed = newValue
    }
    
    public func setBodyguardSpeed(_ newValue1: CGFloat, newValue2: CGFloat, newValue3: CGFloat) -> Void {
        bodyguard1 = newValue1
        bodyguard2 = newValue2
        bodyguard3 = newValue3
    }
    
    public func setInt(_ ForInt: inout Int, newValue: Int) -> Void {
        ForInt = newValue
    }
}
