//
//  PaddleNode.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the class for the bodyguards' SpriteNode.
 */

import SpriteKit
import GameplayKit

public class PaddleNode: SKSpriteNode {
    
    var type: String?
    
    //MARK: Initializer
    
    init(withTexture texture: SKTexture, color: NSColor, position: CGPoint, type: String) {
        
        super.init(texture: texture, color: color, size: texture.size())
        
        //Setting position and name for the SpriteNode...
        self.position = position
        name = "paddle"
        
        //Setting physicsBody properties...
        physicsBody = SKPhysicsBody(rectangleOf: self.size, center: .zero)
        physicsBody?.friction = 0
        physicsBody?.restitution = 1
        physicsBody?.isDynamic = false
        
        //Setting bitmasks...
        physicsBody?.categoryBitMask = BodyType.paddle
        physicsBody?.contactTestBitMask = BodyType.ball
        
        self.type = type
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}


