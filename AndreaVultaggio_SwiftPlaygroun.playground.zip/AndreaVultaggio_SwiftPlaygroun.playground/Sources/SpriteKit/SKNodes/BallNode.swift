//
//  BallNode.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the class for the main character (It's me!). 
 * The name of the classes are derived from the original BlockBreaker-clone project 
 * which I made for the iOS Developer Academy.
 */

import SpriteKit
import GameplayKit

public class BallNode: SKSpriteNode {
    
    //MARK: Initializer
    
    init(withTexture texture: SKTexture, color: NSColor, position: CGPoint) {
        
        super.init(texture: texture, color: color, size: texture.size())
        
        //Setting position and name for the SpriteNode...
        self.position = position
        name = "ball"
        
        //Setting physicsBody properties...
        physicsBody = SKPhysicsBody(rectangleOf: texture.size())
        physicsBody?.friction = 0.0
        physicsBody?.restitution = 1
        physicsBody?.isDynamic = true
        physicsBody?.linearDamping = 0.1
        physicsBody?.angularDamping = 0.1
        physicsBody?.allowsRotation = false
        
        //Setting bitmasks...
        physicsBody?.categoryBitMask = BodyType.ball
        physicsBody?.contactTestBitMask = BodyType.brick | BodyType.bottom | BodyType.paddle
        physicsBody?.fieldBitMask = BodyType.ball
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


