//
//  GameScene.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the class for the main scene.
 */

import SpriteKit
import GameplayKit

//Global constant
let MessageName = "overlay"

public class GameScene: SKScene, SKPhysicsContactDelegate {
    
    //MARK: Properties
    var ballStarted = false
    var lifeLost = false
    
    //GKStateMachine lazy initialization...
    lazy var gameStatus: GKStateMachine = GKStateMachine(states: [
        Waiting(scene: self),
        Playing(scene: self),
         Ending(scene: self)])
    
    //Computed properties...
    var gameWon : Bool = false {
        didSet {
            let gameOver = childNode(withName: MessageName) as! SKLabelNode
            gameOver.text = gameWon ? "You did it!" : "Oh no! WWDC already started..."
            gameOver.run(SKAction.scale(to: 1.0, duration: 0.25))
            
            let gameWonSound = SKAction.playSoundFileNamed("Sounds/gameWonSound.wav", waitForCompletion: true)
            
            let gameOverSound = SKAction.playSoundFileNamed("Sounds/gameOverSound.wav", waitForCompletion: true)
            
            run(gameWon ? gameWonSound : gameOverSound)
        }
    }
    
    var entityManager: EntityManager?
    let sanJose = SKSpriteNode(imageNamed: Textures.paddle.background.rawValue)
    
    //I've got the power! (This is an SKRadialGravityFieldNode which allows you to help me go to the WWDC 2017)
    let power = SKFieldNode.radialGravityField()
    let circle = SKSpriteNode(texture: SKTexture.init(imageNamed: Textures.power.frame1.rawValue))
    var timerLabel = SKLabelNode()
    
    let explosion = [SKTexture.init(imageNamed: Textures.power.frame1.rawValue),
                     SKTexture.init(imageNamed: Textures.power.frame2.rawValue),
                     SKTexture.init(imageNamed: Textures.power.frame3.rawValue),
                     SKTexture.init(imageNamed: Textures.power.frame4.rawValue),
                     SKTexture.init(imageNamed: Textures.power.frame5.rawValue),
                     SKTexture.init(imageNamed: Textures.power.frame6.rawValue),
                     SKTexture.init(imageNamed: Textures.power.frame7.rawValue)]
    
    //More computed properties...
    var levelTimerValue: Int = timeLeft {
        didSet {
            timerLabel.text = "time left: \(levelTimerValue)"
        }
    }
    
    override public func didMove(to view: SKView) {
        
        sanJose.anchorPoint = CGPoint(x: 0, y: 0)
        sanJose.zPosition = -1
        addChild(sanJose)
        
        //Setting the EdgeLoop for the Scene...
        physicsBody = SKPhysicsBody(edgeLoopFrom: self.frame)     
        physicsBody?.friction = 0
        physicsBody?.categoryBitMask = BodyType.borders
        
        //Setting the EntityManager...
        entityManager = EntityManager(scene: self)
        
        //Setting the PhysicsWorld...
        physicsWorld.contactDelegate = self
        physicsWorld.gravity = CGVector(dx: 0.0, dy: 0.0)
        
        //Setting a different physics body for the detection of collision/contact of the ball(Me) with the bottom of the screen (entering the WWDC! :D)...
        let bottomRect = CGRect(x: frame.origin.x, y: frame.origin.y, width: frame.size.width, height: 1)
        let bottom = SKNode()
        bottom.physicsBody = SKPhysicsBody(edgeLoopFrom: bottomRect)
        bottom.physicsBody?.categoryBitMask = BodyType.bottom
        addChild(bottom)
        
        //Drawing some elements on screen...
        entityManager?.drawBricks()
        entityManager?.drawBall()
        entityManager?.drawPaddle()
        
        self.backgroundColor = NSColor(red: 0.98, green: 0.94, blue: 0.88, alpha: 1)
        
        //Setting the timer...
        timerLabel = SKLabelNode(text: "time left: \(levelTimerValue)")
        timerLabel.fontName = "ArcadeClassic"
        timerLabel.fontSize = 60
        timerLabel.position = CGPoint(x: 1024, y: 1460)
        timerLabel.fontColor = NSColor(red: 0.61, green: 0.48, blue: 0.33, alpha: 1)
        timerLabel.isHidden = true
    
        circle.isHidden = true
        
        self.addChild(timerLabel)
        self.addChild(circle)
        
        //Setting THE POWER...!
        power.isEnabled = false
        power.region = SKRegion(radius: radius)
        power.categoryBitMask = BodyType.power
        power.strength = strength
    
        self.circle.addChild(power)
        
        //Setting the starting message and entering in Waiting state...
        let message = SKLabelNode(text: "Click to Play")
        message.fontName = "ArcadeClassic"
        message.fontSize = 144
        message.fontColor = .yellow 
        message.name = MessageName
        message.position = CGPoint(x: frame.midX, y: frame.midY)
        message.zPosition = 10
        message.setScale(0.0)
        addChild(message)
        
        gameStatus.enter(Waiting.self)
        
    }
    
    //MARK: SKPhysicsContactDelegate methods.
    public func didBegin(_ contact: SKPhysicsContact) {
        
        //Checking GameStatus to know if collision can be detected...
        if gameStatus.currentState is Playing {
            
            //If the ball (Me) hits a brick...
            if (contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask) == 7 {
                
                if contact.bodyA.categoryBitMask == BodyType.brick {
                    
                    let ball = contact.bodyB.node as! BallNode
                    ball.run(SKAction.playSoundFileNamed("/Sounds/beep1", waitForCompletion: false))
                    let brickNode = contact.bodyA.node as! BrickNode
                    let brick = entityManager?.getEntity(type: brickNode.type!)
                    entityManager?.remove(entity: brick!)
                    
                    var numberOfBricks = 0
                    
                    //Counting the remaining bricks...
                    self.enumerateChildNodes(withName: "brick", using: {
                        node, stop in
                        numberOfBricks = numberOfBricks + 1
                    })
                    
                    //If all the bricks are destroyed before entering the WWDC the game is lost!
                    if numberOfBricks == 0 {
                        gameWon = false
                        gameStatus.enter(Ending.self)
                        print("GAME LOST")
                    }
                }
            }
                
            //If the ball(aka Me) hits the bottom I finally entered at the WWDC 2017!
            else if (contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask) == 35 {
               
                if !ballStarted{
                    ballStarted = true
                    
                    //And the winner is...
                    if winner() {
                        gameWon = true
                        gameStatus.enter(Ending.self)
                        
                    }
                }
                else {
                    ballStarted = false
                }
            }
        }
    }
    
    //MARK: SKSceneDelegate
    public override func update(_ currentTime: TimeInterval) {
        //checking and updating GKStateMachine status...
        gameStatus.update(deltaTime: currentTime)
    }
    
    //MARK: Event handlers...
    
    //If I click with the mouse...
    public override func mouseDown(with event: NSEvent) {
        
        switch gameStatus.currentState {
            
            case is Waiting:
                
                //Start the game...
                timerLabel.isHidden = false
                gameStatus.enter(Playing.self)
            
            case is Playing:
                
                //Enable the power!
                if event.clickCount == 1 {
                    circle.isHidden = false
                    let animation = SKAction.animate(with: explosion, timePerFrame: 0.15)

                    let point = self.convertPoint(fromView: event.locationInWindow)
                    circle.position = point
                    power.isEnabled = true
                    
                    circle.run(animation)
                }
            
            case is Ending:
                
                //preparing a new scene for a new game...
                let new = GameScene(size: CGSize(width: 2048, height: 1536))
                new.scaleMode = .aspectFit
                let reveal = SKTransition.crossFade(withDuration: 0.5)
                self.view?.presentScene(new, transition: reveal)
                
            default:
                break
            
        }
        
    }
    
    //If I leave the click...
    public override func mouseUp(with event: NSEvent) {
       power.isEnabled = false
       circle.isHidden = true
    }
    
    //Checking if the game is won...
    func winner() -> Bool {
        var numberOfBricks = 0
        
        self.enumerateChildNodes(withName: "brick", using: {
            node, stop in
            numberOfBricks = numberOfBricks + 1
        })
        
        return numberOfBricks > 0
    }
    
}

