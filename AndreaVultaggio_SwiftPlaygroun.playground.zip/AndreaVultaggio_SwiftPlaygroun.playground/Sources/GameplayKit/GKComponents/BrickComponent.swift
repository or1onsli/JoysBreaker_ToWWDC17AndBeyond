//
//  BrickComponent.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the class for the brick's custom GKComponent.
 */

import GameplayKit
import SpriteKit

class BrickComponent: GKComponent {
    
    //This component contains an SKSpriteNode as property...
    let node: BrickNode
    
    //Initialization...
    init(sprite: String, position: CGPoint, type: String){
        let texture = SKTexture(imageNamed: sprite)
        node = BrickNode(withTexture: texture, color: .clear, position: position, type: type)
        super.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

