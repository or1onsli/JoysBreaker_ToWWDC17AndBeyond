//
//  BallComponent.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the class for the ball's (It's me!) custom GKComponent.
 */

import GameplayKit
import SpriteKit

class BallComponent: GKComponent {
    
    //This component contains an SKSpriteNode as property...
    let node: BallNode
    
    //Initialization...
    init(sprite: String, position: CGPoint){
        let texture = SKTexture(imageNamed: sprite)
        node = BallNode(withTexture: texture, color: .clear, position: position)
        super.init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

