//
//  Ending.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the GKState which handles the end of the game...
 */

import SpriteKit
import GameplayKit

class Ending: GKState {
    
    //reference to the GameScene...
    unowned let scene: GameScene
    
    var ballNode: BallNode
    
    //Initializer...
    init(scene: SKScene) {
        self.scene = scene as! GameScene
        let ballEntity = self.scene.entityManager?.getEntity(type: "ball")
        let ballComponent = ballEntity?.component(ofType: BallComponent.self)
        self.ballNode = (ballComponent?.node)!
        super.init()
    }
    
    override func didEnter(from previousState: GKState?) {
        
        if previousState is Playing {
            
            //When the game stops we give some gravity to the scene...
            ballNode.physicsBody!.linearDamping = 1.0
            scene.physicsWorld.gravity = CGVector(dx: 0, dy: -9.8)
            
            //Then we stop the timer...
            scene.removeAllActions()
        
            let gameWonSound = SKAction.playSoundFileNamed("Sounds/gameWonSound.wav", waitForCompletion: true)
            
            let gameOverSound = SKAction.playSoundFileNamed("Sounds/gameOverSound.wav", waitForCompletion: true)
            
            //If you win the bodyguards are out...
            if scene.gameWon {
                removeBodyguards()
                scene.run(gameWonSound)
            }
            else{
            //...and if you lose YOU (aka Me) are out of the WWDC 2017... :(
                ballNode.removeFromParent()
                scene.run(gameOverSound)
            }
        }
    }
    
    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        return stateClass is Waiting.Type
    }
    
    //This function gets a reference for each bodyguard, stops them and then removes
    //them all from the scene...
    func removeBodyguards() -> Void {
        
        let paddle1 = scene.entityManager?.getEntity(type: "bodyguard1")
        let paddle2 = scene.entityManager?.getEntity(type: "bodyguard2")
        let paddle3 = scene.entityManager?.getEntity(type: "bodyguard3")
        let paddle4 = scene.entityManager?.getEntity(type: "bodyguard4")
        let paddle5 = scene.entityManager?.getEntity(type: "bodyguard5")
        let paddle6 = scene.entityManager?.getEntity(type: "bodyguard6")
        
        let component1 = paddle1?.component(ofType: PaddleComponent.self)
        let component2 = paddle2?.component(ofType: PaddleComponent.self)
        let component3 = paddle3?.component(ofType: PaddleComponent.self)
        let component4 = paddle4?.component(ofType: PaddleComponent.self)
        let component5 = paddle5?.component(ofType: PaddleComponent.self)
        let component6 = paddle6?.component(ofType: PaddleComponent.self)
        
        let paddleSprite1 = component1?.node
        let paddleSprite2 = component2?.node
        let paddleSprite3 = component3?.node
        let paddleSprite4 = component4?.node
        let paddleSprite5 = component5?.node
        let paddleSprite6 = component6?.node
        
        paddleSprite1?.removeAllActions()
        paddleSprite2?.removeAllActions()
        paddleSprite3?.removeAllActions()
        paddleSprite4?.removeAllActions()
        paddleSprite5?.removeAllActions()
        paddleSprite6?.removeAllActions()
        
        scene.entityManager?.remove(entity: paddle1!)
        scene.entityManager?.remove(entity: paddle2!)
        scene.entityManager?.remove(entity: paddle3!)
        scene.entityManager?.remove(entity: paddle4!)
        scene.entityManager?.remove(entity: paddle5!)
        scene.entityManager?.remove(entity: paddle6!)
        
    }
    
}
