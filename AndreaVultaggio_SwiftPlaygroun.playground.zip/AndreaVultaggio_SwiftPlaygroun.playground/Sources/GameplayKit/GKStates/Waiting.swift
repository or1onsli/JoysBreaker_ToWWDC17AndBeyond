//
//  Waiting.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the GKState which handles the game before its start...
 */

import GameplayKit
import SpriteKit

class Waiting: GKState {
    
    //reference to the GameScene...
    unowned let scene: GameScene
    
    //Initializer...
    init(scene: SKScene) {
        
        self.scene = scene as! GameScene
        super.init()
    }
    
    override func didEnter(from previousState: GKState?) {
        
        let backgroundSound = SKAction.playSoundFileNamed("Sounds/background.wav", waitForCompletion: false)
        
        scene.run(backgroundSound)
        
        //Showing the tapToPlay message...
        let scale = SKAction.scale(to: 1.0, duration: 0.25)
        guard let s = scene.childNode(withName: MessageName) else {
            fatalError("SCENE RETURNED NIL!")
        }
        s.run(scale)
    }
    
    override func willExit(to nextState: GKState) {
        
        //Once clicking the message fades out and we can start playing!
        if nextState is Playing {
            let scale = SKAction.scale(to: 0, duration: 0.4)
            scene.childNode(withName: MessageName)!.run(scale)
        }
    }
    
    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        return stateClass is Playing.Type
    }
}


