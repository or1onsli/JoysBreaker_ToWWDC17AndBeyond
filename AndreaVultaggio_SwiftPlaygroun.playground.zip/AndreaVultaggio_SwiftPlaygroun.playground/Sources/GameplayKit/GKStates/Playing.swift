//
//  Playing.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the GKState which handles the game during playtime...
 */

import GameplayKit
import SpriteKit

class Playing: GKState {
    
    //reference to the GameScene...
    unowned let scene: GameScene
    
    var ballNode: BallNode
    
    //Initializer...
    init(scene: SKScene) {
        self.scene = scene as! GameScene
        let ballEntity = self.scene.entityManager?.getEntity(type: "ball")
        let ballComponent = ballEntity?.component(ofType: BallComponent.self)
        self.ballNode = (ballComponent?.node)!
        super.init()
    }
    
    override func didEnter(from previousState: GKState?) {
        if previousState is Waiting {
            
            //Let's make this ball (It's Me!) start some movement...
            ballNode.physicsBody?.applyImpulse(CGVector(dx: impulseValue, dy: impulseValue + 15))
            
            let paddle1 = scene.entityManager?.getEntity(type: "bodyguard1")
            let paddle2 = scene.entityManager?.getEntity(type: "bodyguard2")
            let paddle3 = scene.entityManager?.getEntity(type: "bodyguard3")
            let paddle4 = scene.entityManager?.getEntity(type: "bodyguard4")
            let paddle5 = scene.entityManager?.getEntity(type: "bodyguard5")
            let paddle6 = scene.entityManager?.getEntity(type: "bodyguard6")
            
            let component1 = paddle1?.component(ofType: PaddleComponent.self)
            let component2 = paddle2?.component(ofType: PaddleComponent.self)
            let component3 = paddle3?.component(ofType: PaddleComponent.self)
            let component4 = paddle4?.component(ofType: PaddleComponent.self)
            let component5 = paddle5?.component(ofType: PaddleComponent.self)
            let component6 = paddle6?.component(ofType: PaddleComponent.self)
            
            let paddleSprite1 = component1?.node
            let paddleSprite2 = component2?.node
            let paddleSprite3 = component3?.node
            let paddleSprite4 = component4?.node
            let paddleSprite5 = component5?.node
            let paddleSprite6 = component6?.node
            
            //Setting the movement of the bodyguards...
            let interval1 = TimeInterval(((paddleSprite1?.position.x)! - (paddleSprite3?.position.x)!) / bodyguard1)
            
            paddleSprite1?.run(SKAction.repeatForever(SKAction.sequence([SKAction.moveTo(x: (paddleSprite3?.position.x)!, duration: interval1), SKAction.moveTo(x: 879, duration: interval1)])))
            
            let interval2 = TimeInterval((1441.5 - (paddleSprite2?.position.x)!) / bodyguard2)
            
            paddleSprite2?.run(SKAction.repeatForever(SKAction.sequence([SKAction.moveTo(x: 1441.5, duration: interval2), SKAction.moveTo(x: 1169, duration: interval2)])))
            
            let interval3 = TimeInterval(((paddleSprite3?.position.x)! - 127.8) / bodyguard3)
            
            paddleSprite3?.run(SKAction.repeatForever(SKAction.sequence([SKAction.moveTo(x: 127.8, duration: interval3), SKAction.moveTo(x: 606.5, duration: interval3)])))
            
            paddleSprite4?.run(SKAction.repeatForever(SKAction.sequence([SKAction.moveTo(x: 1920.2, duration: interval3), SKAction.moveTo(x: 1441.5, duration: interval3)])))
            
            paddleSprite5?.run(SKAction.repeatForever(SKAction.sequence([SKAction.moveTo(x: 606.5, duration: interval3), SKAction.moveTo(x: 127.8, duration: interval3)])))
            
            paddleSprite6?.run(SKAction.repeatForever(SKAction.sequence([SKAction.moveTo(x: 1920.2, duration: interval3), SKAction.moveTo(x: 1714, duration: interval3)])))
            
            //Setting the timer...
            let wait = SKAction.wait(forDuration: 1)
            let block = SKAction.run({
                [unowned self] in
                
                if self.scene.levelTimerValue > 0{
                    self.scene.levelTimerValue -= 1
                }else{
                    self.scene.gameWon = false
                    self.scene.gameStatus.enter(Ending.self)
                    
                }
            })
                        
            let sequence = SKAction.sequence([wait,block])
            
            //Starting the timer...
            self.scene.run(SKAction.repeatForever(sequence), withKey: "countdown")
            
            
        }
    }
    
    override func update(deltaTime seconds: TimeInterval) {
        
        //If the ball moves too fast increments linearDamping to make it go slower...
        if normalizeVect(x: (ballNode.physicsBody?.velocity.dx)!, y: (ballNode.physicsBody?.velocity.dy)! ) > maxSpeed {
            ballNode.physicsBody?.linearDamping = 0.6
        }
        else {
            ballNode.physicsBody?.linearDamping = 0.1
        }
        
    }
    
    override func isValidNextState(_ stateClass: AnyClass) -> Bool {
        return stateClass is Ending.Type
    }
    
    //This function normalizes a vector and returns a CGFloat...
    func normalizeVect(x: CGFloat, y: CGFloat) -> CGFloat {
        let result = Float(x*x + y*y)
        return CGFloat(sqrtf(result))
    }
}

