//
//  BrickEntity.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the class for the brick's custom GKEntity.
 */

import AppKit
import SpriteKit
import GameplayKit

class BrickEntity: GKEntity {
    
    let type: String?
    
    //Initializer...
    init(sprite: String, position: CGPoint, type: String) {
        
        self.type = type
        super.init()
        
        //Initializing and adding components...
        let brick = BrickComponent(sprite: sprite, position: position, type: self.type!)
        addComponent(brick)

    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

