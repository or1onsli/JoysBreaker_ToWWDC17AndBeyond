//
//  BallEntity.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the class for the ball's (it's Me!) custom GKEntity.
 */

import AppKit
import SpriteKit
import GameplayKit

class BallEntity: GKEntity {
    
    let type = "ball"
    
    //Initializer...
    init(sprite: String, position: CGPoint){
        
        super.init()
        
        //initializing and adding components...
        let ball = BallComponent(sprite: sprite, position: position)
                addComponent(ball)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

