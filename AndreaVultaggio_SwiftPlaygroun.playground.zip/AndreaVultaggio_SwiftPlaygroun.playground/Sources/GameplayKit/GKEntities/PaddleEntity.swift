//
//  PaddleEntity.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the class for the bodyguards' custom GKEntity.
 */

import AppKit
import SpriteKit
import GameplayKit

class PaddleEntity: GKEntity {
    
    let type: String?
    
    //Initializer...
    init(sprite: String, position: CGPoint, type: String) {
        
        self.type = type
        super.init()
        
        //initializing and adding components...
        let paddle = PaddleComponent(sprite: sprite, position: position, type: self.type!)
        addComponent(paddle)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

