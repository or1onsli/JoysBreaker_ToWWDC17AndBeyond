//
//  EntityManager.swift
//
//  Created by Andrea Vultaggio on 27/03/2017.
//  Copyright © 2017 Andrea Vultaggio. All rights reserved.
//

/*
 * This is the class for handling all the game's GKEntities.
 */

import GameplayKit
import SpriteKit

//enum which contains the IDs of the various raw types...
enum rowColors: Int {
    case green1 = 0,
         green2,
         green3,
         yellow,
         orange,
         red,
         purple,
         blue
}

class EntityManager {
    
    //Set<> which contains all the entities inside the game...
    var entities = Set<GKEntity>()
    let scene: SKScene
    
    init(scene: SKScene) {
        self.scene = scene
    }
    
    //MARK: Add/remove functions...
    
    func add(entity: GKEntity) -> Void {
        
        entities.insert(entity)
        
        if let ballNode = entity.component(ofType: BallComponent.self)?.node {
            scene.addChild(ballNode)
        }
        
        if let brickNode = entity.component(ofType: BrickComponent.self)?.node {
            scene.addChild(brickNode)
        }
        
        if let paddleNode = entity.component(ofType: PaddleComponent.self)?.node {
            scene.addChild(paddleNode)
        }
        
    }
    
    //This functions handles entities' removal...
    func remove(entity: GKEntity) -> Void {
        
        if let ballNode = entity.component(ofType: BallComponent.self)?.node {
            ballNode.removeFromParent()
        }
        
        if let brickNode = entity.component(ofType: BrickComponent.self)?.node {
            brickNode.removeFromParent()
        }
        
        if let paddleNode = entity.component(ofType: PaddleComponent.self)?.node {
            paddleNode.removeFromParent()
        }
        
        entities.remove(entity)
    }
    
    //This function returns an entity from it's identifier...
    func getEntity(type: String) -> GKEntity? {
        
        if type == "paddle" {
            for entity in entities {
                if let tmp = entity as? PaddleEntity {
                    if tmp.type == type{
                        return tmp
                    }
                    
                }
            }
        }
            
        else if type == "ball" {
            for entity in entities {
                if let tmp = entity as? BallEntity {
                    return tmp
                }
            }
        }
        
        else {
            for entity in entities {
                if let tmp = entity as? BrickEntity {
                    if tmp.type == type{
                        return tmp
                    }
                    
                }
                if let tmp = entity as? PaddleEntity {
                    if tmp.type == type{
                        return tmp
                    }
                }
            }
        }
        
        return nil
    }
    
    //MARK: Functions for drawing elements on screen...
    
    //Drawing bricks...
    func drawBricks() -> Void {

        let numberOfBricks = 13
        var xPositions: [CGFloat] = []
        
        var counter = 0
        
        for i in 0...numberOfBricks - 1 {
            xPositions.append(CGFloat(brickFirstXPosition + borderBarMin) + CGFloat((brickWidthAndDelta * i)))
        }
        
        for row in 0...7 {
            
            var sprite: String
            
            switch row {
                case 0:
                    sprite = Textures.brick.green.rawValue
                case 1:
                    sprite = Textures.brick.green.rawValue
                case 2:
                    sprite = Textures.brick.green.rawValue
                case 3:
                    sprite = Textures.brick.yellow.rawValue
                case 4:
                    sprite = Textures.brick.orange.rawValue
                case 5:
                    sprite = Textures.brick.red.rawValue
                case 6:
                    sprite = Textures.brick.purple.rawValue
                case 7:
                    sprite = Textures.brick.blue.rawValue
                default:
                    print("ERROR: No valid texture to load!!!")
                    return
                    
            }
            
            let ypos = CGFloat(brickFirstYPosition - brickHeightAndDelta * row)
            
            for column in 0...numberOfBricks - 1 {
                counter += 1
                let brick = BrickEntity(sprite: sprite, position: CGPoint(x: xPositions[column], y: ypos), type: "brick \(counter)")
                self.add(entity: brick)
            }
        }
    }
    
    //Putting bodyguards on screen...
    func drawPaddle() -> Void {
        
        let paddle1 = PaddleEntity(sprite: Textures.paddle.normal.rawValue, position: CGPoint(x: 879, y: paddleY), type: "bodyguard1")
        
        let paddle2 = PaddleEntity(sprite: Textures.paddle.normal.rawValue, position: CGPoint(x: 1169, y: paddleY), type: "bodyguard2")
        
        let paddle3 = PaddleEntity(sprite: Textures.paddle.normal.rawValue, position: CGPoint(x: CGFloat(606.5), y: CGFloat(paddleY + 60)), type: "bodyguard3")
        
        let paddle4 = PaddleEntity(sprite: Textures.paddle.normal.rawValue, position: CGPoint(x: CGFloat(1441.5), y: CGFloat(paddleY + 60)), type: "bodyguard4")
        
        let paddle5 = PaddleEntity(sprite: Textures.paddle.normal.rawValue, position: CGPoint(x: 334, y: CGFloat(paddleY + 120)), type: "bodyguard5")
        
        let paddle6 = PaddleEntity(sprite: Textures.paddle.normal.rawValue, position: CGPoint(x: 1714, y: CGFloat(paddleY + 120)), type: "bodyguard6")
        
        self.add(entity: paddle1)
        self.add(entity: paddle2)
        self.add(entity: paddle3)
        self.add(entity: paddle4)
        self.add(entity: paddle5)
        self.add(entity: paddle6)
    }
    
    //Drawing the ball...(Me!)
    func drawBall() -> Void {

        let ball = BallEntity(sprite: "Textures/ball", position: CGPoint(x: paddleX, y: paddleY + 800))
        self.add(entity: ball)
    }
    
}




