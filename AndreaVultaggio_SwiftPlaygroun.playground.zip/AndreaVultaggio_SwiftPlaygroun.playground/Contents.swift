/*:
# Joys Breaker - To WWDC 2017 and Beyond!
## 🎮 👾 🎮 🤖
### developed by Andrea Vultaggio
 ---
 */
/*:
 ## What is this playground about?
 
 Joys Breaker is a game which came out casually during a brainstorming session with a tutor and a mate at the iOS Developer Academy in Naples. The original concept was about reverting the rules of the original *Breakout* game giving justice to all the destroyed bricks across the years!
 
 For this particular occasion I changed something introducing myself as **The Ball!** I'm there in front of six bodyguards who don't want to let me go into the Pantheon of the App Developers!
 *Help me to conquer the first WWDC of my life, let's get into the McEnery Convention Center*!*/
/*:
 ## How to play it.
 
 To play this game is pretty simple. You have to click with the mouse near my figure to push me around the hall  with your 💪🏻 ***super-user-super-powers*** 💪🏻 and to help me go through security.
 
 - Callout(Warning):
    You only have *100* seconds to help me get in before the conference starts!  ⌚️
 
 The bad guys will push me against the objects at the top of the screen. Since I am stubborn every object that I hurt will break down into pieces (just like my heart if I don't get in 💔)...
 
 - Callout(Warning):
    If we break all the objects before the conference starts I will lose my chance to get in too.   👀
 
 
 Now let's play! */
/*:
 ## Let's do some fine-tuning.
 
 I hope you enjoyed helping me in my achievment, but a lot of work still needs to be done! 💼
 
 I'm giving you the chance to transform it in a real challenging game, how can you do it?
 Pretty simple! Use this set of functions to change the weights of the gameplay:
 
 ---
 
 - *func* setRadius(*_* newValue: **Float**)
 
 This function changes the radius of the circular area of effect of your *super-user-super-power*.
 
 - *func* setStrength(*_* newValue: **Float**)
 
 This function changes the strength of your *super-user-super-power*.
 
 - *func* setMaxSpeed(*_* newValue: **CGFloat**)
 
 This function changes the maxSpeed that you can give to me.
 
 - *func* setBodyguardSpeed(*_* newValue1: **CGFloat**, newValue2: **CGFloat**, newValue3: **CGFloat**)
 
 This function changes the speed of the bodyguards through three parameters.
 
 - *func* setTimeLeft(*_* newValue: **Int**)
 
 This function sets the timer of the game.
 
 ---
 
 - Callout(Warning):
    ⭕️ Use them before initializing the *GameScene* object or your changes will be ignored by the game! ⭕️ */
/*:
 ## Time to play again!
 */
import SpriteKit
import PlaygroundSupport

/*
 * Your code goes HERE.
 */

    let handler = SliderHandler()

    handler.setMaxSpeed(700)


//Initialize the GameScene.
let scene = GameScene(size:CGSize(width: 2048, height: 1536))
let skView = SKView(frame: NSRect(x: 0, y: 0, width: 1024, height: 768))

//Settings.
skView.showsFPS = false
skView.showsNodeCount = false
skView.ignoresSiblingOrder = true
skView.showsPhysics = false

//Presenting scene.
scene.scaleMode = .aspectFill
skView.presentScene(scene)

PlaygroundPage.current.liveView = skView
